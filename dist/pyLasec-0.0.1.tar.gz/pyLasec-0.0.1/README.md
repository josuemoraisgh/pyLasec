# pyLasec
Library with resources used by the Control and Automation Engineering course at the Federal University of Uberlândia

## Usage:
### install with pip:
```shell
pip install pyLasec
```
### Import on your code:
```python
from pyLasec import serialGui
```
### Run it
```python
```

## Collaborate
#### Create issues, PR's and share the project, it's open-source!!

___
# How to...
## Print something
Use the key-word print on your string
```python
```
## Declare a variable
Use the key-word variável on your string
```python
```

# Help us to improve the pt-BR features and create an english translator!
